console.log(data)

/* for loop */
