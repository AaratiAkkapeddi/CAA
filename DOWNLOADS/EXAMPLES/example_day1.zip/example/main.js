
/*********** UFO SHAPES ARE EITHER ******/
      /*
      circle, 
      sphere, 
      triangle, 
      delta, 
      unknown, 
      cigar, 
      chevron, 
      oval, 
      light, 
      fireball, 
      rectangle, 
      disk, 
      other
      */


/* TO ACCESS OUR DATA FILE */
// $.ajax ({ url: "./ufo.json", method: "GET"})
// .success(function (response) {
   
   /* VISUALIZATION CODE GOES HERE */
 
// });